This code was taken from Alec Jacobson's matlab fileexchange 
(http://www.mathworks.com/matlabcentral/fileexchange/49692-gptoolbox)

To get more code or information, please download the full library. To get great information about computer graphics and interesting code snippets, go to Alec's blog:
http://www.alecjacobson.com/weblog/